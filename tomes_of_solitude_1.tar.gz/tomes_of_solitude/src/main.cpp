#include <math.h>
#include <map>
#include <queue>
#include <vector>
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#define GL_GLEXT_PROTOTYPES
#include <GL/gl.h>
#include <GL/glext.h>

using namespace std;

#define TICK_TIME (0.016666666f)


//##############################################################################
// Type declarations
//##############################################################################
typedef struct
{
	GLuint tex;
	int have_item;
} Item;

#define OT_PLAYER 0
#define OT_INVENTORY 1
#define OT_ENEMY 2
#define OT_BOOK 3
#define OT_FIRST_BOSS 4
#define OT_SECOND_BOSS 5
#define OT_FENCE 6
#define OT_FOURTH_BOSS 7

#define BLOCKADE_TILE 8
#define FLOOR_TILE 1

typedef struct
{
	int type;
	int x, y;
	int w, h;
	float life;
	bool alive;
	unsigned char data[256-sizeof(int)*5-sizeof(bool)-sizeof(float)];
} ObjectFormat;

typedef struct
{
	int object_idx;
	int anim;
	float anim_time;
	float invul_time;
	float life;
	float speed;
	float x, y;
	float w, h;
	float mx, my;
	int dx, dy;
	int remove;
} Enemy;

#define C_POTION       0
#define C_BOOK_ARSON   1
#define C_BOOK_LIGHT   2
#define C_BOOK_OIL     3
#define C_BOOK_NULLIFY 4
#define C_BOOK_EMBER   5

typedef struct
{
	GLuint tex;
	float x, y;
	float w, h;
	int id;
} Collectible;

typedef struct
{
	int object_idx;
	GLuint tex;
	float x, y;
	float w, h;
	float life;
	float state_ttl;
	float shoot_time;
	float invul_time;
	float report_time;
	float reported_life;
	int state;
} FirstBoss;

typedef struct
{
	int object_idx;
	GLuint tex;
	bool is_lasing;
	float x, y;
	float w, h;
	float life;
	float state_ttl;
	float shoot_time;
	float invul_time;
	float report_time;
	float reported_life;
	int state;
} FourthBoss;

typedef struct
{
	int object_idx;
	GLuint tex;
	float x, y;
	float vx, vy;
	float w, h;
	float life;
	float state_ttl;
	float shoot_time;
	float invul_time;
	float report_time;
	float reported_life;
	int state;
} SecondBoss;

typedef struct
{
	int object_idx;
	GLuint tex;
	int anim;
	float anim_time;
	float invul_time;
	float life;
	float speed; // Speed
	float x, y; // Position
	float w, h; // Size
	float mx, my; // Movement
	int dx, dy; // Direction (for drawing)
	int active_slot; // Active inventory slot
	bool nullify_active;
	bool light_active;
} Player;

typedef struct
{
	bool left;
	bool right;
	bool up;
	bool down;
	bool z;
	bool enter;
	bool escape;
} Controls;

typedef struct
{
	unsigned char tiles[20*13];
	unsigned char shadow[20*13];
	unsigned char collision[20*13];
	int x, y;
} Map;

typedef struct
{
	float x, y;
	float vx, vy;
	float ttl;
	bool from_oil;
	int oil_id;
} Particle;

typedef struct
{
	float x, y;
	float vx, vy;
	float ttl;
} Spark;

typedef struct
{
	float x, y;
	float vx, vy;
	float ttl;
	float fly_ttl;
	bool on_fire;
} OilParticle;

typedef struct
{
	float x, y;
	float vx, vy;
	float ttl;
	float r, g, b, a;
	int n;
} NumberParticle;

//##############################################################################
// Static variables
//##############################################################################
static int m_gamestate = 0;
static SDL_Surface * m_screen = NULL;
static bool m_running = true;
static int m_mouse_x = 0;
static int m_mouse_y = 0;
static GLuint m_tex_cursor = 0;
static GLuint m_tex_spark = 0;
static GLuint m_tex_win = 0;
static GLuint m_tex_overlay = 0;
static GLuint m_tex_tiles = 0;
static GLuint m_tex_fire = 0;
static GLuint m_tex_font = 0;
static GLuint m_tex_main = 0;
static GLuint m_tex_potion = 0;
static GLuint m_tex_fence = 0;
static GLuint m_tex_oil = 0;
static GLuint m_tex_nullify = 0;
static GLuint m_tex_boss1 = 0;
static GLuint m_tex_boss2 = 0;
static GLuint m_tex_boss4 = 0;
static GLuint m_tex_instructions = 0;
static GLuint m_tex_book = 0;
static Mix_Chunk * m_snd_potion = NULL;
static Mix_Chunk * m_snd_hurt_spark = NULL;
static Mix_Chunk * m_snd_flames = NULL;
static Mix_Chunk * m_snd_boss_die = NULL;
static Mix_Chunk * m_snd_menu_blip = NULL;
static Mix_Chunk * m_snd_book = NULL;

GLuint m_tex_enemy = 0;
static int m_items_object_idx = 0;
static Item m_items[5];
static Map m_current_map;
static Map m_next_map;
static bool m_developer = false;
static vector<Enemy> m_enemies;
static vector<Particle> m_flames;
static vector<OilParticle> m_oils;
static vector<NumberParticle> m_numbers;
static vector<ObjectFormat> m_objects;
static vector<Collectible> m_collectibles;
static vector<Spark> m_sparks;
static int m_font_index[256];
static float m_text_ttl = 0.0f;
static char m_text[64];

static FirstBoss m_boss1;
static SecondBoss m_boss2;
static FirstBoss m_boss3;
static FourthBoss m_boss4;

static bool m_left_mouse_down = false;
static bool m_right_mouse_down = false;
static bool m_middle_mouse_down = false;
static int m_current_tile = 1;
static Player m_player;
static Controls m_ctrls;

static int m_transitioning = false;
static float m_transition_timer = 0.0f;
static int m_transition_dir_x = 0;
static int m_transition_dir_y = 0;

int handle_blockades(Map * map);
void draw_textured_rect(GLuint texture, int left, int right, int top, int bottom);
void draw_textured_sub_rect(GLuint texture, int left, int right, int top, int bottom,
	float tleft, float tright, float ttop, float tbottom);
void draw_colored_rect(int left, int right, int top, int bottom, float r, float g, float b, float a);

void set_text(const char * text)
{
	strcpy(m_text, text);
	m_text_ttl = 5.0f;
}

void reset_game()
{
	m_objects.clear();
	m_enemies.clear();
	m_flames.clear();
	m_numbers.clear();
	m_collectibles.clear();
	m_oils.clear();
	m_sparks.clear();
}

int loop_sound(Mix_Chunk * chunk)
{
	int result = 0;
	if(chunk != NULL) {
		if((result = Mix_PlayChannel(-1, chunk, -1)) == -1) {
			fprintf(stderr, "Mix_PlayChannel: %s\n", Mix_GetError());
		}
	}
	return result;
}

void play_sound(Mix_Chunk * chunk)
{
	if(chunk != NULL) {
		if(Mix_PlayChannel(-1, chunk, 0) == -1) {
			fprintf(stderr, "Mix_PlayChannel: %s\n", Mix_GetError());
		}
	}
}

void spawn_book(int x, int y, int book)
{
	Collectible col;
	col.tex = m_items[book-C_BOOK_ARSON].tex;
	col.x = x;
	col.y = y;
	col.w = 32;
	col.h = 32;
	col.id = book;
	m_collectibles.push_back(col);
}

void spawn_potion(int x, int y)
{
	Collectible col;
	col.tex = m_tex_potion;
	col.id = C_POTION;
	col.x = x;
	col.y = y;
	col.w = 32;
	col.h = 32;
	m_collectibles.push_back(col);
}

void initialize_memory()
{
	m_ctrls = { false, false, false, false };

	char font[] = "abcdefghijklmnopqrstuvwxyz0123456789 ";
	for(int i = 0; font[i]; i++) {
		m_font_index[(int)font[i]] = i;
	}
}

int load_texture(const char * name, GLuint * texid)
{
	SDL_Surface * loaded_image = IMG_Load(name);
	if(loaded_image == NULL) {
		fprintf(stderr, "Failed to load image: %s with error: %s\n",
			name, IMG_GetError());
		return -1;
	}

	SDL_Surface * image = SDL_DisplayFormatAlpha(loaded_image);
	if(image == NULL) {
		fprintf(stderr, "Failed to convert image %s to display format\n",
			name);
		return -1;
	}
	SDL_FreeSurface(loaded_image);
	loaded_image = NULL;

	glGenTextures(1, texid);
	glBindTexture(GL_TEXTURE_2D, *texid);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	GLint numberOfColors = image->format->BytesPerPixel;
	GLenum textureFormat = 0;
	if(numberOfColors == 4) {
		textureFormat = GL_BGRA;
	} else if(numberOfColors == 3) {
		textureFormat = GL_BGR;
	} else {
		fprintf(stderr, "Image format not supported for %s.\n", name);
		return -1;
	}
	glTexImage2D(GL_TEXTURE_2D, 0, numberOfColors, image->w,
		image->h, 0, textureFormat, GL_UNSIGNED_BYTE, image->pixels);

	SDL_FreeSurface(image);
	image = NULL;
	
	return 0;
}

int initialize_textures()
{
	if(load_texture("res/fence.png", &m_tex_fence) < 0) {
		return -1;
	}
	if(load_texture("res/win.png", &m_tex_win) < 0) {
		return -1;
	}
	if(load_texture("res/spark.png", &m_tex_spark) < 0) {
		return -1;
	}
	if(load_texture("res/boss1.png", &m_tex_boss1) < 0) {
		return -1;
	}
	if(load_texture("res/boss2.png", &m_tex_boss2) < 0) {
		return -1;
	}
	if(load_texture("res/boss4.png", &m_tex_boss4) < 0) {
		return -1;
	}
	if(load_texture("res/potion.png", &m_tex_potion) < 0) {
		return -1;
	}
	if(load_texture("res/oil.png", &m_tex_oil) < 0) {
		return -1;
	}
	if(load_texture("res/nullify.png", &m_tex_nullify) < 0) {
		return -1;
	}
	if(load_texture("res/instructions.png", &m_tex_instructions) < 0) {
		return -1;
	}
	if(load_texture("res/book.png", &m_tex_book) < 0) {
		return -1;
	}
	if(load_texture("res/main.png", &m_tex_main) < 0) {
		return -1;
	}
	if(load_texture("res/font.png", &m_tex_font) < 0) {
		return -1;
	}
	if(load_texture("res/fire.png", &m_tex_fire) < 0) {
		return -1;
	}
	if(load_texture("res/player.png", &m_player.tex) < 0) {
		return -1;
	}
	if(load_texture("res/enemy.png", &m_tex_enemy) < 0) {
		return -1;
	}
	if(load_texture("res/cursor.png", &m_tex_cursor) < 0) {
		return -1;
	}
	if(load_texture("res/overlay.png", &m_tex_overlay) < 0) {
		return -1;
	}
	if(load_texture("res/tiles.png", &m_tex_tiles) < 0) {
		return -1;
	}
	if(load_texture("res/item1.png", &m_items[0].tex) < 0) {
		return -1;
	}
	if(load_texture("res/item2.png", &m_items[1].tex) < 0) {
		return -1;
	}
	if(load_texture("res/item3.png", &m_items[2].tex) < 0) {
		return -1;
	}
	if(load_texture("res/item4.png", &m_items[3].tex) < 0) {
		return -1;
	}
	if(load_texture("res/item5.png", &m_items[4].tex) < 0) {
		return -1;
	}
	return 0;
}

int initialize_video()
{
	SDL_WM_SetCaption("Tomes of Solitude", "");
	SDL_ShowCursor(SDL_DISABLE);
	
	SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
	m_screen = SDL_SetVideoMode(640, 480, 32, SDL_OPENGL | SDL_HWSURFACE | SDL_DOUBLEBUF);
	if(m_screen == NULL) {
		fprintf(stderr, "Failed to set video mode: %s\n", SDL_GetError());
		return -1;
	}

	glViewport(0, 0, m_screen->w, m_screen->h);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0, (double)m_screen->w, (double)m_screen->h, 0.0, 0.0, 1.0);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	return 0;
}

void map_from_coords(int * x, int * y)
{
	*x = floorf(*x / (20.0f*32.0f));
	*y = floorf(*y / (13.0f*32.0f));
}

bool on_map(int x1, int y1, int x2, int y2)
{
	map_from_coords(&x2, &y2);
	if((x1 != x2) || (y1 != y2)) {
		return false;
	} else {
		return true;
	}
}

bool on_same_screen(int x1, int y1, int x2, int y2)
{
	if(m_transitioning) {
		return false;
	}
	
	map_from_coords(&x1, &y1);
	map_from_coords(&x2, &y2);

	if((x1 != x2) || (y1 != y2)) {
		return false;
	} else {
		return true;
	}
}

void tile_from_mouse(int * x, int * y)
{
	*x = m_mouse_x / 32;
	*y = m_mouse_y / 32;
}

int get_tile(int x, int y)
{
	if(x >= 0 && x < 20 && y >= 0 && y < 13) {
		return m_current_map.tiles[x + y * 20];
	}
	return 0;
}

int get_collision_tile(int x, int y)
{
	if(x >= 0 && x < 20 && y >= 0 && y < 13) {
		return m_current_map.collision[x + y * 20];
	}
	return 0;
}

void set_tile(int x, int y, int tile)
{
	if(x >= 0 && x < 20 && y >= 0 && y < 13) {
		m_current_map.tiles[x + y * 20] = tile;
	}
}

void set_shadow_tile(int x, int y, int tile)
{
	if(x >= 0 && x < 20 && y >= 0 && y < 13) {
		m_current_map.shadow[x + y * 20] = tile;
	}
}

void set_collision_tile(int x, int y, int tile)
{
	if(x >= 0 && x < 20 && y >= 0 && y < 13) {
		m_current_map.collision[x + y * 20] = tile;
	}
}

bool colliding(float x1, float y1, float r1, float x2, float y2, float r2)
{
	float dx = x1 - x2;
	float dy = y1 - y2;
	float dist = sqrtf(dx*dx + dy*dy);
	if(dist < (r1 + r2)) {
		return true;
	}
	return false;
}

void tick_collectible(Collectible * col)
{
}

void tick_sparks();
void tick_boss1()
{
	tick_sparks();
	int mid_x = m_boss1.x + m_boss1.w/2;
	int mid_y = m_boss1.y + m_boss1.h/2;
	if(m_boss1.report_time > 0.0f) {
		m_boss1.report_time -= TICK_TIME;
		if(m_boss1.report_time < 0.0f) {
			m_boss1.report_time = 0.0f;
		}
	}
	if(m_boss1.shoot_time > 0.0f) {
		m_boss1.shoot_time -= TICK_TIME;
		if(m_boss1.shoot_time < 0.0f) {
			m_boss1.shoot_time = 0.0f;
		}
	}
	if(m_boss1.state_ttl > 0.0f) {
		m_boss1.state_ttl -= TICK_TIME;
		if(m_boss1.state_ttl < 0.0f) {
			m_boss1.state_ttl = 0.0f;
		}
	}

	// As long as the boss is alive
	if(m_boss1.state != 3) {
		if(m_boss1.life == 0.0f) {
			spawn_book(mid_x + 200, mid_y, C_BOOK_OIL);
			play_sound(m_snd_boss_die);
			m_boss1.state = 3;
		}

		for(unsigned int i = 0; i < m_flames.size(); i++) {
			if(colliding(mid_x, mid_y, 64, m_flames[i].x, m_flames[i].y, 16)) {

				if(m_flames[i].from_oil) {
					m_boss1.life = fmaxf(0.0f, m_boss1.life-0.000008f);
				} else {
					m_boss1.life = fmaxf(0.0f, m_boss1.life-0.00008f);
				}

				if(m_boss1.report_time == 0.0f) {
					NumberParticle part;
					part.x = mid_x;
					part.y = m_boss1.y;
					part.vx = 0.0f;
					part.vy = -2.0f;
					part.ttl = 0.5f;
					part.r = 1.0f;
					part.g = 0.0f;
					part.b = 0.0f;
					part.a = 1.0f;
					part.n = (m_boss1.reported_life - m_boss1.life) * 10000.0f;
					m_numbers.push_back(part);
					m_boss1.reported_life = m_boss1.life;
					m_boss1.report_time = 0.1f;
				}
			}
		}
	}


	if(m_boss1.state == 0) {
		if(m_boss1.state_ttl == 0.0f) {
			m_boss1.state = 1;
			m_boss1.state_ttl = 3.0f;
		}
	} else if(m_boss1.state == 1) {
		// Shoot
		if(m_boss1.shoot_time == 0.0f) {
			Spark spark;
			spark.x = m_boss1.x + 128;
			spark.y = m_boss1.y + 60;
			spark.ttl = 1.0f;

			float dx = m_player.x - spark.x;
			float dy = m_player.y - spark.y;
			float len = sqrtf(dx*dx + dy*dy);
			spark.vx = dx;
			spark.vy = dy; 
			if(len != 0.0f) {
				spark.vx /= len;
				spark.vy /= len;
			}

			spark.vx *= 5.0f;
			spark.vy *= 5.0f;
			m_sparks.push_back(spark);
			m_boss1.shoot_time = 0.1f;
		}
		if(m_boss1.state_ttl == 0.0f) {
			m_boss1.state = 0;
			m_boss1.state_ttl = 4.0f;
		}
	}
}


void draw_boss1()
{
	if(m_boss1.life == 0.0f) {
		return;
	}

	float left = m_boss1.x;
	float right = left + m_boss1.w;
	float top = m_boss1.y;
	float bottom = top + m_boss1.h;
	draw_textured_rect(m_tex_boss1, left, right, top, bottom);


	int mapx = m_boss1.x;
	int mapy = m_boss1.y;
	map_from_coords(&mapx, &mapy);

	left = mapx*20*32 + 20;
	right = left + 600;
	top = mapy*13*32 + 10;
	bottom = top + 10;
	draw_colored_rect(left, right, top, bottom, 0.4f, 0.0f, 0.0f, 1.0f);

	right = left + 600 * m_boss1.life;
	draw_colored_rect(left, right, top, bottom, 1.0f, 0.0f, 0.0f, 1.0f);
}

bool is_colliding(float px, float py, float w, float h);

void tick_boss2()
{
	int mid_x = m_boss2.x + m_boss2.w/2;
	int mid_y = m_boss2.y + m_boss2.h/2;
	if(m_boss2.report_time > 0.0f) {
		m_boss2.report_time -= TICK_TIME;
		if(m_boss2.report_time < 0.0f) {
			m_boss2.report_time = 0.0f;
		}
	}
	if(m_boss2.shoot_time > 0.0f) {
		m_boss2.shoot_time -= TICK_TIME;
		if(m_boss2.shoot_time < 0.0f) {
			m_boss2.shoot_time = 0.0f;
		}
	}
	if(m_boss2.state_ttl > 0.0f) {
		m_boss2.state_ttl -= TICK_TIME;
		if(m_boss2.state_ttl < 0.0f) {
			m_boss2.state_ttl = 0.0f;
		}
	}

	// As long as the boss is alive
	if(m_boss2.state != 3) {
		if(m_boss2.life == 0.0f) {
			int mapx = m_boss2.x;
			int mapy = m_boss2.y;
			map_from_coords(&mapx, &mapy);
			spawn_book(mapx*20*32+320, mapy*13*32+240, C_BOOK_NULLIFY);
			play_sound(m_snd_boss_die);
			m_boss2.state = 3;
		}

		for(unsigned int i = 0; i < m_flames.size(); i++) {
			if(colliding(mid_x, mid_y, 64, m_flames[i].x, m_flames[i].y, 16)) {

				if(m_flames[i].from_oil) {
					m_boss2.life = fmaxf(0.0f, m_boss2.life-0.000008f);
				} else {
					m_boss2.life = fmaxf(0.0f, m_boss2.life-0.000008f);
				}

				if(m_boss2.report_time == 0.0f) {
					NumberParticle part;
					part.x = mid_x;
					part.y = m_boss2.y;
					part.vx = 0.0f;
					part.vy = -2.0f;
					part.ttl = 0.5f;
					part.r = 1.0f;
					part.g = 0.0f;
					part.b = 0.0f;
					part.a = 1.0f;
					part.n = (m_boss2.reported_life - m_boss2.life) * 10000.0f;
					m_numbers.push_back(part);
					m_boss2.reported_life = m_boss2.life;
					m_boss2.report_time = 0.1f;
				}
			}
		}
	}

	if(m_boss2.state == 0) {

		float speed = 8.0f;


		m_boss2.vx += ((rand() / (float)RAND_MAX) - 0.5f) * 0.1f;
		m_boss2.vy += ((rand() / (float)RAND_MAX) - 0.5f) * 0.1f;

		float len = sqrtf(m_boss2.vx*m_boss2.vx + m_boss2.vy*m_boss2.vy);
		if(len != 0.0f) {
			m_boss2.vx /= len;
			m_boss2.vy /= len;
		}
		
		if(is_colliding(m_boss2.x+m_boss2.vx*speed, m_boss2.y, 128, 128)) {
			m_boss2.vx *= -1.0f;
		}
		if(is_colliding(m_boss2.x, m_boss2.y+m_boss2.vy*speed, 128, 128)) {
			m_boss2.vy *= -1.0f;
		}

		m_boss2.x += m_boss2.vx*speed;
		m_boss2.y += m_boss2.vy*speed;
	}
}

void draw_boss2()
{
	if(m_boss2.life == 0.0f) {
		return;
	}

	float left = m_boss2.x;
	float right = left + m_boss2.w;
	float top = m_boss2.y;
	float bottom = top + m_boss2.h;
	draw_textured_rect(m_tex_boss2, left, right, top, bottom);


	int mapx = m_boss2.x;
	int mapy = m_boss2.y;
	map_from_coords(&mapx, &mapy);

	left = mapx*20*32 + 20;
	right = left + 600;
	top = mapy*13*32 + 10;
	bottom = top + 10;

	draw_colored_rect(left, right, top, bottom, 0.4f, 0.0f, 0.0f, 1.0f);

	right = left + 600 * m_boss2.life;
	draw_colored_rect(left, right, top, bottom, 1.0f, 0.0f, 0.0f, 1.0f);
}

void tick_boss3()
{
}


void draw_boss3()
{
	float left = m_boss3.x;
	float right = left + m_boss3.w;
	float top = m_boss3.y;
	float bottom = top + m_boss3.h;


	if(((int)(m_boss3.invul_time * 20)) % 2 == 0) {
		draw_textured_sub_rect(m_tex_fence, left, right, top, bottom,
			0.0f, 1.0f, 0.0f, 0.5f);
	} else {
		draw_textured_sub_rect(m_tex_fence, left, right, top, bottom,
			0.0f, 1.0f, 0.5f, 1.0f);
	}
	m_boss3.invul_time += TICK_TIME;
}

void tick_boss4()
{
	tick_sparks();
	int mid_x = m_boss4.x + m_boss4.w/2;
	int mid_y = m_boss4.y + m_boss4.h/2;
	if(m_boss4.report_time > 0.0f) {
		m_boss4.report_time -= TICK_TIME;
		if(m_boss4.report_time < 0.0f) {
			m_boss4.report_time = 0.0f;
		}
	}
	if(m_boss4.shoot_time > 0.0f) {
		m_boss4.shoot_time -= TICK_TIME;
		if(m_boss4.shoot_time < 0.0f) {
			m_boss4.shoot_time = 0.0f;
		}
	}
	if(m_boss4.state_ttl > 0.0f) {
		m_boss4.state_ttl -= TICK_TIME;
		if(m_boss4.state_ttl < 0.0f) {
			m_boss4.state_ttl = 0.0f;
		}
	}

	// As long as the boss is alive
	if(m_boss4.state != 4) {
		if(m_boss4.life == 0.0f) {
			spawn_book(mid_x + 200, mid_y, C_BOOK_LIGHT);
			spawn_book(mid_x + 200, mid_y+30, C_BOOK_EMBER);
			play_sound(m_snd_boss_die);
			m_boss4.state = 4;
			m_boss4.is_lasing = false;
		}

		for(unsigned int i = 0; i < m_flames.size(); i++) {
			if(colliding(mid_x, mid_y, 64, m_flames[i].x, m_flames[i].y, 16)) {

				if(m_flames[i].from_oil) {
					m_boss4.life = fmaxf(0.0f, m_boss4.life-0.000008f);
				} else {
					m_boss4.life = fmaxf(0.0f, m_boss4.life-0.000008f);
				}

				if(m_boss4.report_time == 0.0f) {
					NumberParticle part;
					part.x = mid_x;
					part.y = m_boss4.y;
					part.vx = 0.0f;
					part.vy = -2.0f;
					part.ttl = 0.5f;
					part.r = 1.0f;
					part.g = 0.0f;
					part.b = 0.0f;
					part.a = 1.0f;
					part.n = (m_boss4.reported_life - m_boss4.life) * 10000.0f;
					m_numbers.push_back(part);
					m_boss4.reported_life = m_boss4.life;
					m_boss4.report_time = 0.1f;
				}
			}
		}
	}


	if(m_boss4.state == 0) {
		if(m_boss4.state_ttl == 0.0f) {
			m_boss4.state = 1;
			m_boss4.state_ttl = 3.0f;
		}
	} else if(m_boss4.state == 1) {
		// Shoot
		if(m_boss4.shoot_time == 0.0f) {
			Spark spark;
			spark.x = m_boss4.x + 128;
			spark.y = m_boss4.y + 60;
			spark.ttl = 1.0f;

			float dx = m_player.x - spark.x;
			float dy = m_player.y - spark.y;
			float len = sqrtf(dx*dx + dy*dy);
			spark.vx = dx;
			spark.vy = dy; 
			if(len != 0.0f) {
				spark.vx /= len;
				spark.vy /= len;
			}

			spark.vx *= 5.0f;
			spark.vy *= 5.0f;
			m_sparks.push_back(spark);
			m_boss4.shoot_time = 0.1f;
		}
		if(m_boss4.state_ttl == 0.0f) {
			m_boss4.state = 2;
			m_boss4.state_ttl = 4.0f;
		}
	} else if(m_boss4.state == 2) {
		// Pause before laser
		if(m_boss4.state_ttl == 0.0f) {
			m_boss4.state = 3;
			m_boss4.state_ttl = 4.0f;
		}
	} else if(m_boss4.state == 3) {
		// Laser
		m_boss4.is_lasing = true;

		if(m_boss4.state_ttl == 0.0f) {
			m_boss4.is_lasing = false;
			m_boss4.state = 0;
			m_boss4.state_ttl = 1.0f;
		}
	}
}

void draw_boss4()
{
	if(m_boss4.life == 0.0f) {
		return;
	}

	float left = m_boss4.x;
	float right = left + m_boss4.w;
	float top = m_boss4.y;
	float bottom = top + m_boss4.h;
	draw_textured_rect(m_tex_boss4, left, right, top, bottom);


	int mapx = m_boss4.x;
	int mapy = m_boss4.y;
	map_from_coords(&mapx, &mapy);

	left = mapx*20*32 + 20;
	right = left + 600;
	top = mapy*13*32 + 10;
	bottom = top + 10;
	draw_colored_rect(left, right, top, bottom, 0.4f, 0.0f, 0.0f, 1.0f);

	right = left + 600 * m_boss4.life;
	draw_colored_rect(left, right, top, bottom, 1.0f, 0.0f, 0.0f, 1.0f);

	if(m_boss4.is_lasing) {
		glBindTexture(GL_TEXTURE_2D, 0);
		glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
		glBegin(GL_LINES);
		for(int i = 0; i < 5; i++) {
			float xoff = ((rand() / (float)RAND_MAX) -0.5f) * 5.0f;
			float yoff = ((rand() / (float)RAND_MAX) -0.5f) * 5.0f;
			glVertex2f(m_boss4.x + 64 + xoff, m_boss4.y + 20 + yoff);
			glVertex2f(m_player.x + m_player.w/2 + xoff, m_player.y + m_player.h/2 + yoff);
		}
		glEnd();
	}
	
}

void tick_enemy(Enemy * enemy)
{
	if(enemy->invul_time > 0.0f) {
		enemy->invul_time -= TICK_TIME;
		if(enemy->invul_time < 0.0f) {
			enemy->invul_time = 0.0f;
		}
	}

	if(m_player.invul_time == 0.0f && !m_player.nullify_active) {
		if(colliding(enemy->x+enemy->w/2, enemy->y+enemy->h/2, enemy->w / 2.0f,
				m_player.x+m_player.w/2, m_player.y+m_player.h/2, 18.0f)) {
			m_player.life -= 0.05f;
			m_player.invul_time = 0.3f;
			
			NumberParticle part;
			part.x = m_player.x + m_player.w / 2;
			part.y = m_player.y;
			part.vx = 0.0f;
			part.vy = -2.0f;
			part.ttl = 0.5f;
			part.r = 1.0f;
			part.g = 0.0f;
			part.b = 0.0f;
			part.a = 1.0f;
			part.n = 5;
			m_numbers.push_back(part);
		}
	}

	for(unsigned int i = 0; i < m_flames.size(); i++) {
		if(colliding(enemy->x+enemy->w/2, enemy->y+enemy->h/2, enemy->w / 2.0f, m_flames[i].x, m_flames[i].y, 16.0f)) {
			if(!(m_flames[i].vx == 0.0f && m_flames[i].vy == 0.0f)) {
				if(!m_flames[i].from_oil) {
					m_flames[i].vx = 0.0f;
					m_flames[i].vy = 0.0f;
					m_flames[i].ttl = 0.4f;
				}
				if(enemy->invul_time == 0.0f) {
					enemy->life -= 0.4f;
					enemy->invul_time = 0.1f;
					NumberParticle part;
					part.x = enemy->x + enemy->w / 2;
					part.y = enemy->y;
					part.vx = 0.0f;
					part.vy = -2.0f;
					part.ttl = 0.5f;
					part.r = 1.0f;
					part.g = 0.0f;
					part.b = 0.0f;
					part.a = 1.0f;
					part.n = 40;
					m_numbers.push_back(part);
				}
			}
			if(enemy->life <= 0.0f) {
				enemy->remove = 1;
			}
		}
	}

	
	float dx = m_player.x - enemy->x;
	float dy = m_player.y - enemy->y;
	float dist = sqrtf(dx*dx + dy*dy);

	//float speed = 2.0f;
	float destx = m_player.x - 32.0f * (dx / dist);
	float desty = m_player.y - 32.0f * (dy / dist);

	dx = destx - enemy->x;
	dy = desty - enemy->y;
	dist = sqrtf(dx*dx + dy*dy);

	if(dist < 1.0f) {
		enemy->anim = 0;
		enemy->mx = 0.0f;
		enemy->my = 0.0f;
		return;
	} else if(dist > 0.0f) {
		enemy->anim_time += TICK_TIME;
		enemy->mx = dx / dist;
		enemy->my = dy / dist;
		if(fabsf(enemy->mx) > fabsf(enemy->my)) {
			enemy->dx = enemy->mx < 0.0f ? -1 : 1;
			enemy->dy = 0;
		} else {
			enemy->dx = 0;
			enemy->dy = enemy->my < 0.0f ? -1 : 1;
		}
	} else {
		enemy->mx = 0.0f;
		enemy->my = 0.0f;
	}

	float len = sqrtf(enemy->mx*enemy->mx + enemy->my * enemy->my);
	if(len != 0.0f) {
		enemy->mx /= len;
		enemy->my /= len;
	}
}

int save_objects();

void pickup_collectible(Collectible * col)
{
	if(col->id == C_BOOK_ARSON) {
		m_items[0].have_item = true;
		save_objects();
		play_sound(m_snd_book);
	} else if(col->id == C_BOOK_LIGHT) {
		m_items[1].have_item = true;
		save_objects();
		play_sound(m_snd_book);
	} else if(col->id == C_BOOK_OIL) {
		m_items[2].have_item = true;
		save_objects();
		set_text("a door opens in the east");
		play_sound(m_snd_book);
	} else if(col->id == C_BOOK_NULLIFY) {
		m_items[3].have_item = true;
		save_objects();
		play_sound(m_snd_book);
	} else if(col->id == C_BOOK_EMBER) {
		m_items[4].have_item = true;
		save_objects();
		play_sound(m_snd_book);
	} else if(col->id == C_POTION) {
		m_player.life += 0.1f;
		m_player.life = fminf(1.0f, m_player.life);
		play_sound(m_snd_potion);
	}
}

bool colliding_rect(float left1, float right1, float top1, float bottom1,
	float left2, float right2, float top2, float bottom2)
{
	if(bottom1 < top2) return false;
	if(top1 > bottom2) return false;
	if(right1 < left2) return false;
	if(left1 > right2) return false;
	return true;
}

void tick_player()
{
	if(m_player.invul_time > 0.0f) {
		m_player.invul_time -= TICK_TIME;
		if(m_player.invul_time < 0.0f) {
			m_player.invul_time = 0.0f;
		}
	}

	if(m_player.invul_time == 0.0f && !m_player.nullify_active) {

		if(m_boss4.life > 0.0f && m_boss4.is_lasing) {
			m_player.life -= 0.007f;
			m_player.invul_time = 0.0f;
			//play_sound(m_snd_hurt_spark);
		}

		if(m_boss1.life > 0.0f && colliding(m_player.x+m_player.w/2, m_player.y+m_player.h/2, m_player.w / 2.0f,
				m_boss1.x+64, m_boss1.y+64, 40)) {
			m_player.life -= 0.3f;
			m_player.invul_time = 0.4f;
			play_sound(m_snd_hurt_spark);
		}

		if(m_boss2.life > 0.0f && colliding(m_player.x+m_player.w/2, m_player.y+m_player.h/2, m_player.w / 2.0f,
				m_boss2.x+64, m_boss2.y+64, 48)) {
			m_player.life -= 0.1f;
			m_player.invul_time = 1.0f;
			play_sound(m_snd_hurt_spark);
		}

		if(colliding_rect(m_player.x, m_player.x+m_player.w, m_player.y, m_player.y+m_player.h,
				m_boss3.x, m_boss3.x + m_boss3.w, m_boss3.y, m_boss3.y + m_boss3.h)) {
			m_player.life -= 1.0f;
			m_player.invul_time = 0.0f;
			play_sound(m_snd_hurt_spark);
		}
		
		for(unsigned int i = 0; i < m_sparks.size(); i++) {
			if(colliding(m_player.x+m_player.w/2, m_player.y+m_player.h/2, m_player.w / 2.0f,
					m_sparks[i].x, m_sparks[i].y,16.0f)) {
				m_player.life -= 0.1f;
				m_player.invul_time = 0.4f;
				play_sound(m_snd_hurt_spark);
			}
		}
	}

	for(unsigned int i = 0; i < m_collectibles.size(); i++) {
		if(colliding(m_player.x+m_player.w/2, m_player.y+m_player.h/2, m_player.w / 2.0f,
				m_collectibles[i].x + m_collectibles[i].w/2, m_collectibles[i].y + m_collectibles[i].h/2,
				m_collectibles[i].w / 2.0f)) {
			pickup_collectible(&m_collectibles[i]);
			m_collectibles[i] = m_collectibles.back();
			m_collectibles.pop_back();
		}
	}

	if(!m_player.nullify_active) {
		for(unsigned int i = 0; i < m_flames.size(); i++) {
			if(!m_flames[i].from_oil) {
				continue;
			}
			if(colliding(m_player.x+m_player.w/2, m_player.y+m_player.h/2, m_player.w / 2.0f, m_flames[i].x, m_flames[i].y, 16.0f)) {
				if(m_player.invul_time == 0.0f) {
					m_player.life -= 0.02f;
					m_player.invul_time = 0.2f;
					NumberParticle part;
					part.x = m_player.x + m_player.w / 2;
					part.y = m_player.y;
					part.vx = 0.0f;
					part.vy = -2.0f;
					part.ttl = 0.5f;
					part.r = 1.0f;
					part.g = 0.0f;
					part.b = 0.0f;
					part.a = 1.0f;
					part.n = 2;
					m_numbers.push_back(part);
				}
				break;
			}
		}
	}

	
	m_player.anim_time += TICK_TIME;
	float mx = 0.0f;
	float my = 0.0f;
	float speed = m_player.speed;

	// Build movement and direction vector
	if(!m_transitioning) {
		m_player.nullify_active = false;
		if(m_ctrls.left) {
			mx = -1.0f;
			if(!m_ctrls.z) {
				m_player.dx = -1;
			}
		} else if(m_ctrls.right) {
			mx = 1.0f;
			if(!m_ctrls.z) {
				m_player.dx = 1;
			}
		}
		if(m_ctrls.up) {
			my = -1.0f;
			if(!m_ctrls.z) {
				m_player.dy = -1;
			}
		} else if(m_ctrls.down) {
			my = 1.0f;
			if(!m_ctrls.z) {
				m_player.dy = 1;
			}
		}
		if(m_ctrls.z) {
			if(m_player.active_slot == 0 && m_items[0].have_item) {
				Particle flame;
				flame.x = m_player.x + m_player.w / 2;
				flame.y = m_player.y + m_player.h / 2;
				flame.x += m_player.dx * (m_player.w/1.5f);
				flame.y += m_player.dy * (m_player.h/1.5f);
				flame.vx = m_player.dx;
				flame.vy = m_player.dy;
				float len = sqrtf(flame.vx * flame.vx + flame.vy * flame.vy);
				flame.vx += (rand() / (float)RAND_MAX - 0.5f) / 1.5f;
				flame.vy += (rand() / (float)RAND_MAX - 0.5f) / 1.5f;
				flame.vx /= len;
				flame.vy /= len;
				flame.ttl = 0.5f;
				flame.vx *= 5.0f;
				flame.vy *= 5.0f;
				flame.from_oil = false;
				m_flames.push_back(flame);
			} else if(m_player.active_slot == 3 && m_items[3].have_item) {
				m_player.nullify_active = true;
			} else if(m_player.active_slot == 2 && m_items[2].have_item) {
				// Find oldest oil
				int lowest_idx = -1;
				if(m_oils.size() > 300) {
					float lowest_ttl = 100000.0f;
					for(unsigned int i = 0; i < m_oils.size(); i++) {
						if(m_oils[i].ttl < lowest_ttl) {
							lowest_idx = i;
							lowest_ttl = m_oils[i].ttl;
						}
					}
				}
				OilParticle oil;
				oil.x = m_player.x + m_player.w / 2;
				oil.y = m_player.y + m_player.h / 2;
				oil.x += m_player.dx * (m_player.w/1.5f);
				oil.y += m_player.dy * (m_player.h/1.5f);
				oil.vx = m_player.dx;
				oil.vy = m_player.dy;
				float len = sqrtf(oil.vx * oil.vx + oil.vy * oil.vy);
				oil.vx += (rand() / (float)RAND_MAX - 0.5f) / 2.0f;
				oil.vy += (rand() / (float)RAND_MAX - 0.5f) / 2.0f;
				oil.vx /= len;
				oil.vy /= len;
				oil.fly_ttl = 0.5f;
				oil.ttl = 25.0f;
				oil.vx *= 5.0f;
				oil.vy *= 5.0f;
				if(lowest_idx >= 0) {
					m_oils[lowest_idx] = oil;
				} else {
					m_oils.push_back(oil);
				}
			}
		}
	} else {
		mx = m_transition_dir_x;
		my = m_transition_dir_y;
		m_player.dx = m_transition_dir_x;
		m_player.dy = m_transition_dir_y;
		speed = 1.5f;
	}

	if(mx == 0.0f && my != 0.0f) {
		if(!m_ctrls.z) {
			m_player.dx = 0;
		}
	} else if(my == 0.0f && mx != 0.0f) {
		if(!m_ctrls.z) {
			m_player.dy = 0;
		}
	}

	// Normalize movement vector
	float len = sqrtf(mx * mx + my * my);
	if(len != 0.0f) {
		mx /= len;
		my /= len;
	}

	// Add magnitude to movement
	mx *= speed;
	my *= speed;

	// Store movement vector
	m_player.mx = mx;
	m_player.my = my;

	// Apply movement
	m_player.x += mx;
	m_player.y += my;
}

bool is_colliding(float px, float py, float w, float h)
{
	float pleft = px - m_current_map.x * 20.0f * 32.0f;
	float pright = pleft + w;
	float ptop = py - m_current_map.y * 13.0f * 32.0f;
	float pbottom = ptop + h;

	int left = (int)floorf(pleft / 32.0f);
	int right = (int)floorf(pright / 32.0f);
	int top = (int)floorf(ptop / 32.0f);
	int bottom = (int)floorf(pbottom / 32.0f);

	for(int y = top; y <= bottom; y++) {
		for(int x = left; x <= right; x++) {

			if(get_collision_tile(x,y) == 0) {
				continue;
			}
			
			float phw = w / 2.0f;
			float phh = h / 2.0f;
			float pmidx = px + phw;
			float pmidy = py + phh;

			float thw = 16.0f;
			float thh = 16.0f;
			float tmidx = m_current_map.x * 20.0f * 32.0f + x * 32.0f + thw;
			float tmidy = m_current_map.y * 13.0f * 32.0f + y * 32.0f + thh;

			float xdist = fabsf(pmidx - tmidx) - (phw + thw);
			float ydist = fabsf(pmidy - tmidy) - (phh + thh);

			if(xdist < 0.0f && ydist < 0.0f) {
				return true;
			}
		}
	}
	return false;
}

void handle_collision(float * px, float * py, float w, float h)
{
	float pleft = *px - m_current_map.x * 20.0f * 32.0f;
	float pright = pleft + w;
	float ptop = *py - m_current_map.y * 13.0f * 32.0f;
	float pbottom = ptop + h;


	int left = (int)floorf(pleft / 32.0f);
	int right = (int)floorf(pright / 32.0f);
	int top = (int)floorf(ptop / 32.0f);
	int bottom = (int)floorf(pbottom / 32.0f);

	for(int y = top; y <= bottom; y++) {
		for(int x = left; x <= right; x++) {
			if(get_collision_tile(x,y) == 0) {
				continue;
			}

			float phw = w / 2.0f;
			float phh = h / 2.0f;
			float pmidx = *px + phw;
			float pmidy = *py + phh;

			float thw = 16.0f;
			float thh = 16.0f;
			float tmidx = m_current_map.x * 20.0f * 32.0f + x * 32.0f + thw;
			float tmidy = m_current_map.y * 13.0f * 32.0f + y * 32.0f + thh;

			float xdist = fabsf(pmidx - tmidx) - (phw + thw);
			float ydist = fabsf(pmidy - tmidy) - (phh + thh);

			if(xdist < 0.0f && ydist < 0.0f) {
				float xoverlap = fabsf(xdist);
				float yoverlap = fabsf(ydist);

				if(fabsf(xoverlap - yoverlap) < 2.0f) {
					if(!is_colliding(*px + xoverlap * (pmidx > tmidx ? 1.0f : -1.0f), *py, w, h)) {
						*px += xoverlap * (pmidx > tmidx ? 1.0f : -1.0f);
					} else if(!is_colliding(*px, *py + yoverlap * (pmidy > tmidy ? 1.0f : -1.0f), w, h)) {
						*py += yoverlap * (pmidy > tmidy ? 1.0f : -1.0f);
					} else if(xoverlap <= yoverlap) {
						*px += xoverlap * (pmidx > tmidx ? 1.0f : -1.0f);
					} else {
						*py += yoverlap * (pmidy > tmidy ? 1.0f : -1.0f);
					}
				} else if(xoverlap <= yoverlap) {
					*px += xoverlap * (pmidx > tmidx ? 1.0f : -1.0f);
				} else {
					*py += yoverlap * (pmidy > tmidy ? 1.0f : -1.0f);
				}
			}
		}
	}
}

int load_map(int x, int y, Map * map);
void save_map();


void boidify_enemies()
{
	for(unsigned int i = 0; i < m_enemies.size(); i++) {
		float x = 0.0f;
		float y = 0.0f;

		if(!on_same_screen(m_enemies[i].x, m_enemies[i].y, m_player.x, m_player.y)) {
			continue;
		}
		
		for(unsigned int j = 0; j < m_enemies.size(); j++) {
			if(i != j) {
				if(!on_same_screen(m_enemies[i].x, m_enemies[i].y, m_enemies[j].x, m_enemies[j].y)) {
					continue;
				}
				
				float x1 = m_enemies[i].x + m_enemies[i].w / 2;
				float y1 = m_enemies[i].y + m_enemies[i].h / 2;
				float x2 = m_enemies[j].x + m_enemies[j].w / 2;
				float y2 = m_enemies[j].y + m_enemies[j].h / 2;
				float dx = x1 - x2;
				float dy = y1 - y2;
				float dist = sqrtf(dx*dx + dy*dy);
				
				if(dist < 32.0f) {
					x = x - (x2 - x1) / 2.0f;
					y = y - (y2 - y1) / 2.0f;
				}
			}
		}

		m_enemies[i].mx += x / 128.0f;
		m_enemies[i].my += y / 128.0f;

		m_enemies[i].mx *= 1.5f;
		m_enemies[i].my *= 1.5f;
	}
}

void tick_sparks()
{
	for(unsigned int i = 0; i < m_sparks.size(); i++) {
		m_sparks[i].x += m_sparks[i].vx;
		m_sparks[i].y += m_sparks[i].vy;
		m_sparks[i].ttl -= TICK_TIME;

		bool delete_spark = false;
		if(m_sparks[i].ttl < 0.0f) {
			delete_spark = true;
		}

		if(delete_spark) {
			m_sparks[i] = m_sparks.back();
			m_sparks.pop_back();
		}
	}
}

void tick_flames()
{
	for(unsigned int i = 0; i < m_flames.size(); i++) {
		m_flames[i].x += m_flames[i].vx;
		m_flames[i].y += m_flames[i].vy;
		m_flames[i].ttl -= TICK_TIME;

		bool delete_flame = false;

		if(m_flames[i].from_oil) {
			if(m_flames[i].oil_id >= (int)m_oils.size()) {
				delete_flame = true;
			} else if(fabsf(m_oils[m_flames[i].oil_id].ttl - m_flames[i].ttl) > 1.0f) {
				delete_flame = true;
			}
		}
		if(m_flames[i].ttl < 0.0f) {
			delete_flame = true;
		}
		if(delete_flame) {
			m_flames[i] = m_flames.back();
			m_flames.pop_back();
		}
	}
}

void tick_oils()
{
	for(unsigned int i = 0; i < m_oils.size(); i++) {
		m_oils[i].x += m_oils[i].vx;
		m_oils[i].y += m_oils[i].vy;
		m_oils[i].fly_ttl -= TICK_TIME;
		m_oils[i].ttl -= TICK_TIME;
		if(m_oils[i].fly_ttl < 0.0f) {
			m_oils[i].vx = 0.0f;
			m_oils[i].vy = 0.0f;

			if(!m_oils[i].on_fire) {
				for(unsigned int j = 0; j < m_flames.size(); j++) {
					if(colliding(m_oils[i].x, m_oils[i].y, 16,
							m_flames[j].x, m_flames[j].y, 16)) {
						m_oils[i].on_fire = true;
						Particle flame;
						flame.from_oil = true;
						flame.oil_id = i;
						flame.x = m_oils[i].x;
						flame.y = m_oils[i].y - 5;
						flame.vx = 0.0f;
						flame.vy = 0.00001f;
						m_oils[i].ttl /= 2.0f;
						flame.ttl = m_oils[i].ttl;
						m_flames.push_back(flame);
						flame.x -= 3;
						flame.y += 3;
						flame.ttl -= 0.3f;
						m_flames.push_back(flame);
						flame.x += 6;
						flame.y -= 6;
						flame.ttl += 0.6f;
						m_flames.push_back(flame);
						break;
					}
				}
			}
		}
		if(m_oils[i].ttl < 0.0f) {
			m_oils[i] = m_oils.back();
			m_oils.pop_back();
		}
	}
}

void tick_numbers()
{
	for(unsigned int i = 0; i < m_numbers.size(); i++) {
		m_numbers[i].x += m_numbers[i].vx;
		m_numbers[i].y += m_numbers[i].vy;
		m_numbers[i].ttl -= TICK_TIME;
		if(m_numbers[i].ttl < 0.0f) {
			m_numbers[i] = m_numbers.back();
			m_numbers.pop_back();
		}
	}
}

int save_objects();

int tick_ingame()
{
	if(m_text_ttl > 0.0f) {
		m_text_ttl -= TICK_TIME;
		if(m_text_ttl < 0.0f) {
			m_text_ttl = 0.0f;
		}
	}
	
	if(m_transitioning) {
		if(m_transition_timer == 0.0f) {
			int load_res = load_map(m_current_map.x + m_transition_dir_x,
				m_current_map.y + m_transition_dir_y, &m_next_map);
			if(load_res < 0) {
				memset(&m_next_map, 0, sizeof(Map));
				m_next_map.x = m_current_map.x + m_transition_dir_x;
				m_next_map.y = m_current_map.y + m_transition_dir_y;
			}
		}
		
		m_transition_timer += TICK_TIME / 0.5f;
		if(m_transition_timer > 1.0f) {
			m_transition_timer = 0.0f;
			m_transitioning = false;
			save_map();
			m_current_map = m_next_map;
		}
	}
	
	if(m_developer) {
		if(m_left_mouse_down) {
			int x, y;
			tile_from_mouse(&x, &y);
			set_tile(x, y, m_current_tile);
		} else if(m_right_mouse_down) {
			int x, y;
			tile_from_mouse(&x, &y);
			set_shadow_tile(x, y, m_current_tile+32);
		} else if(m_middle_mouse_down) {
			int x, y;
			tile_from_mouse(&x, &y);
			set_collision_tile(x, y, m_current_tile);
		}
	}

	tick_player();
	tick_flames();
	tick_numbers();
	tick_oils();

	if(on_same_screen(m_boss1.x, m_boss1.y, m_player.x, m_player.y)) {
		tick_boss1();
	}
	if(on_same_screen(m_boss2.x, m_boss2.y, m_player.x, m_player.y)) {
		tick_boss2();
	}
	if(on_same_screen(m_boss3.x, m_boss3.y, m_player.x, m_player.y)) {
		tick_boss3();
	}
	if(on_same_screen(m_boss4.x, m_boss4.y, m_player.x, m_player.y)) {
		tick_boss4();
	}

	for(unsigned int i = 0; i < m_enemies.size(); i++) {
		if(on_same_screen(m_enemies[i].x, m_enemies[i].y, m_player.x, m_player.y)) {
			tick_enemy(&m_enemies[i]);
		}
	}

	for(unsigned int i = 0; i < m_collectibles.size(); i++) {
		if(on_same_screen(m_collectibles[i].x, m_collectibles[i].y, m_player.x, m_player.y)) {
			tick_collectible(&m_collectibles[i]);
		}
	}
	
	boidify_enemies();

	for(unsigned int i = 0; i < m_enemies.size(); i++) {
		if(on_same_screen(m_enemies[i].x, m_enemies[i].y, m_player.x, m_player.y)) {
			m_enemies[i].x += m_enemies[i].mx;
			m_enemies[i].y += m_enemies[i].my;
		}
	}


	if(!m_developer) {
		handle_collision(&m_player.x, &m_player.y, m_player.w, m_player.h);
	}
	for(unsigned int i = 0; i < m_enemies.size(); i++) {
		if(on_same_screen(m_enemies[i].x, m_enemies[i].y, m_player.x, m_player.y)) {
			handle_collision(&m_enemies[i].x, &m_enemies[i].y, m_enemies[i].w, m_enemies[i].h);
		}
	}

	// Check for map transition
	if(m_player.x < m_current_map.x * 20.0f * 32.0f) {
		m_transitioning = true;
		m_transition_dir_x = -1;
		m_transition_dir_y = 0;
	} else if(m_player.x + m_player.w >= m_current_map.x * 20.0f * 32.0f + 20*32.0f) {
		m_transitioning = true;
		m_transition_dir_x = 1;
		m_transition_dir_y = 0;
	} else if(m_player.y < m_current_map.y * 13.0f * 32.0f) {
		m_transitioning = true;
		m_transition_dir_x = 0;
		m_transition_dir_y = -1;
	} else if(m_player.y + m_player.h >= m_current_map.y * 13.0f * 32.0f + 13 * 32.0f) {
		m_transitioning = true;
		m_transition_dir_x = 0;
		m_transition_dir_y = 1;
	}

	//m_player.life = (fabsf(sinf(SDL_GetTicks()/ 1000.0f)));

	for(unsigned int i = 0; i < m_enemies.size(); i++) {
		if(m_enemies[i].remove) {
			if(rand() % 15 == 0) {
				spawn_potion(m_enemies[i].x, m_enemies[i].y);
				//spawn_book(m_enemies[i].x, m_enemies[i].y, C_BOOK_OIL);
			}
			m_objects[m_enemies[i].object_idx].alive = false;
			m_enemies[i] = m_enemies.back();
			m_enemies.pop_back();
			if(handle_blockades(&m_current_map)) {
				save_objects();
			}
		}
	}

	if(m_player.life <= 0.0f) {
		m_gamestate = 0;
		m_player.life = 0.0f;
		reset_game();
	}

	if(m_ctrls.escape) {
		m_gamestate = 0;
		m_ctrls.escape = false;
	}
	
	return 0;
}

void draw_text(int x, int y, const char * text, float r, float g, float b, float a)
{
	glBindTexture(GL_TEXTURE_2D, m_tex_font);
	glColor4f(r, g, b, a);
	glBegin(GL_QUADS);
	for(int i = 0; text[i]; i++) {
		int row = m_font_index[(int)text[i]] / 16;
		int col = m_font_index[(int)text[i]] % 16;

		float left = x+i*8;
		float right = x+i*8 + 8;
		float top = y;
		float bottom = y + 8;

		float tleft = col / 16.0f;
		float tright = tleft + 1.0f / 16.0f;
		float ttop = row / 16.0f;
		float tbottom = ttop + 1.0f / 16.0f;

		glTexCoord2f(tleft, ttop);
		glVertex2f(left, top);

		glTexCoord2f(tright, ttop);
		glVertex2f(right, top);

		glTexCoord2f(tright, tbottom);
		glVertex2f(right, bottom);

		glTexCoord2f(tleft, tbottom);
		glVertex2f(left, bottom);
	}
	glEnd();
}

void draw_number(int x, int y, int n, float r, float g, float b, float a)
{
	char buffer[16];
	sprintf(buffer, "%d", n);
	draw_text(x, y, buffer, r, g, b, a);
}

void draw_textured_sub_rect(GLuint texture, int left, int right, int top, int bottom,
	float tleft, float tright, float ttop, float tbottom)
{
	glBindTexture(GL_TEXTURE_2D, texture);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
		glTexCoord2f(tleft, ttop);
		glVertex2f(left, top);

		glTexCoord2f(tright, ttop);
		glVertex2f(right, top);

		glTexCoord2f(tright, tbottom);
		glVertex2f(right, bottom);

		glTexCoord2f(tleft, tbottom);
		glVertex2f(left, bottom);
	glEnd();
}

void draw_colored_rect(int left, int right, int top, int bottom, float r, float g, float b, float a)
{
	glBindTexture(GL_TEXTURE_2D, 0);
	glColor4f(r, g, b, a);
	glBegin(GL_QUADS);
	glVertex2f(left, top);
	glVertex2f(right, top);
	glVertex2f(right, bottom);
	glVertex2f(left, bottom);
	glEnd();
}

void draw_textured_rect_with_alpha(GLuint texture, int left, int right, int top, int bottom, float alpha)
{
	glBindTexture(GL_TEXTURE_2D, texture);
	glColor4f(1.0f, 1.0f, 1.0f, alpha);
	glPushMatrix();
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(left, top);

		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(right, top);

		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(right, bottom);

		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(left, bottom);
	glEnd();
	glPopMatrix();
}

void draw_textured_rect(GLuint texture, int left, int right, int top, int bottom)
{
	glBindTexture(GL_TEXTURE_2D, texture);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(left, top);

		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(right, top);

		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(right, bottom);

		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(left, bottom);
	glEnd();
}

void draw_collectibles()
{
	for(unsigned int i = 0; i < m_collectibles.size(); i++) {
		draw_textured_rect(m_collectibles[i].tex,
			m_collectibles[i].x, m_collectibles[i].x + m_collectibles[i].w,
			m_collectibles[i].y, m_collectibles[i].y + m_collectibles[i].h);
	}
}

void draw_enemy(Enemy * enemy)
{
	// Set animation row
	int row = 0;
	if(enemy->dx == 1) {
		row = 2;
	} else if(enemy->dx == -1) {
		row = 0;
	} else if(enemy->dy == -1) {
		row = 1;
	} else if(enemy->dy == 1) {
		row = 3;
	}

	// Set animation column
	if(enemy->mx == 0.0f && enemy->my == 0.0f) {
		enemy->anim = 0;
		enemy->anim_time = 0.0f;
	}
	enemy->anim = ((int)(enemy->anim_time / 0.16f)) % 4;

	// Draw player
	int x = (int)roundf(enemy->x);
	int y = (int)roundf(enemy->y);
	float tleft = enemy->anim * (1.0f / 8.0f);
	float tright = tleft + (1.0f / 8.0f);
	float ttop = row * (1.0f / 8.0f);
	float tbottom = ttop + (1.0f / 8.0f);

	if((int)(enemy->invul_time * 100) % 2 == 0) {
		draw_textured_sub_rect(m_tex_enemy, x, x + 32, y, y + 32,
			tleft, tright, ttop, tbottom);
	}
}

void draw_flying_oils()
{
	for(unsigned int i = 0; i < m_oils.size(); i++) {
		if(m_oils[i].fly_ttl > 0.0f) {
			draw_textured_rect(m_tex_oil,
				m_oils[i].x - 16, m_oils[i].x + 16,
				m_oils[i].y - 16, m_oils[i].y + 16);
		}
	}
}

void draw_landed_oils()
{
	for(unsigned int i = 0; i < m_oils.size(); i++) {
		if(m_oils[i].fly_ttl <= 0.0f) {
			draw_textured_rect(m_tex_oil,
				m_oils[i].x - 16, m_oils[i].x + 16,
				m_oils[i].y - 16, m_oils[i].y + 16);
		}
	}
}

void draw_sparks()
{
	glBindTexture(GL_TEXTURE_2D, m_tex_spark);
	glBegin(GL_QUADS);
	for(unsigned int i = 0; i < m_sparks.size(); i++) {
		float scale = 16.0f;
		float left = m_sparks[i].x - scale;
		float right = m_sparks[i].x + scale;
		float top = m_sparks[i].y - scale;
		float bottom = m_sparks[i].y + scale;
		
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(left, top);

		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(right, top);

		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(right, bottom);

		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(left, bottom);
	}
	glEnd();
}

void draw_flames()
{
	glBindTexture(GL_TEXTURE_2D, m_tex_fire);
	glBegin(GL_QUADS);
	for(unsigned int i = 0; i < m_flames.size(); i++) {
		float scale = 0.0f;
		float alpha = 0.5f;
		// Flickr flames from oil
		if(m_flames[i].from_oil) {
			int show = (int)(m_flames[i].ttl * 10) % 2;
			if(show) {
				continue;
			}
			scale = 16.0f;
		} else {
			scale = 16.0f * (1.5f - m_flames[i].ttl) * (1.5f - m_flames[i].ttl);
			alpha = m_flames[i].ttl / 0.5f;
		}

		float left = m_flames[i].x - scale;
		float right = m_flames[i].x + scale;
		float top = m_flames[i].y - scale;
		float bottom = m_flames[i].y + scale;
			
		glColor4f(1.0f, 1.0f, 1.0f, alpha);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(left, top);

		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(right, top);

		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(right, bottom);

		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(left, bottom);
	}
	glEnd();
}

void draw_numbers()
{
	for(unsigned int i = 0; i < m_numbers.size(); i++) {
		draw_number(m_numbers[i].x, m_numbers[i].y, m_numbers[i].n,
			m_numbers[i].r, m_numbers[i].g, m_numbers[i].b, m_numbers[i].a);
	}
}

void draw_player()
{
	if(m_player.dy != 1) {
		draw_flames();
		draw_flying_oils();
	}
	
	// Set animation row
	int row = -1;
	if(m_player.dx == 1) {
		row = 2;
	} else if(m_player.dx == -1) {
		row = 0;
	} else if(m_player.dy == -1) {
		row = 1;
	} else if(m_player.dy == 1) {
		row = 3;
	}

	// Set animation column
	if(m_player.mx == 0.0f && m_player.my == 0.0f) {
		m_player.anim = 0;
		m_player.anim_time = 0.0f;
	}
	m_player.anim = ((int)(m_player.anim_time / 0.16f)) % 4;
	if(m_ctrls.z) {
		m_player.anim = 4;
	}

	int x = (int)roundf(m_player.x);
	int y = (int)roundf(m_player.y);

	// Draw shadow
	draw_textured_sub_rect(m_player.tex, x, x + 32, y+2, y + 32+2,
		5.0f / 8.0f, 6.0f / 8.0f, 0.0f / 8.0f, 1.0f / 8.0f);

	// Draw player
	float tleft = m_player.anim * (1.0f / 8.0f);
	float tright = tleft + (1.0f / 8.0f);
	float ttop = row * (1.0f / 8.0f);
	float tbottom = ttop + (1.0f / 8.0f);

	if((int)(m_player.invul_time * 100) % 2 == 0) {
		draw_textured_sub_rect(m_player.tex, x, x + 32, y, y + 32,
			tleft, tright, ttop, tbottom);
	}

	if(m_player.nullify_active) {
		draw_textured_rect(m_tex_nullify, x-16, x + 32+16, y - 16, y + 32+16);
	}

	if(m_player.dy == 1) {
		draw_flames();
		draw_flying_oils();
	}

}

void draw_cursor()
{
	draw_textured_rect(m_tex_cursor, m_mouse_x, m_mouse_x+32, m_mouse_y, m_mouse_y+32);
}

void draw_win_screen()
{
	draw_textured_rect(m_tex_win, 320-64, 320+64, 240-64, 240+64);
}

void draw_overlay()
{
	draw_textured_rect(m_tex_overlay, 0, m_screen->w, 0, m_screen->h);

	if(m_text_ttl > 0.0f) {
		draw_text(3, 460, m_text, 1.0f, 1.0f, 1.0f, 1.0f);
	}
}

void draw_inventory()
{
	int top = 440;
	int bottom = top + 32;
	int left = 206;
	int stride = 50;

	for(int i = 0; i < 5; i++) {
		int item_left = left + stride * i;
		if(m_player.active_slot == i) {
			draw_colored_rect(item_left-10, item_left+32+6, top-6, bottom+4, 0.0f, 0.7f, 0.0f, 0.5f);
		}
		if(m_items[i].have_item) {
			draw_textured_rect(m_items[i].tex, item_left, item_left+32, top, bottom);
		}
	}
}

void draw_life()
{
	float left = 196.0f;
	float top = 420.0f;
	float bottom = top + 11.0f;
	float right = left + (m_player.life * (443.0f - left));

	glBindTexture(GL_TEXTURE_2D, 0);
	glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
	glBegin(GL_QUADS);
	glVertex2f(left, top);
	glVertex2f(right, top);
	glVertex2f(right, bottom);
	glVertex2f(left, bottom);
	glEnd();
}

int draw_collision_tile(int tile, int x, int y)
{
	if(tile == 0) {
		return 0;
	}
	if(tile != 0) {
		glVertex2f(x, y);
		glVertex2f(x+32, y);
		
		glVertex2f(x+32, y);
		glVertex2f(x+32, y+32);
		
		glVertex2f(x+32, y+32);
		glVertex2f(x, y+32);

		glVertex2f(x, y+32);
		glVertex2f(x, y);
	}
	return 0;
}

int draw_tile(int tile, int x, int y)
{
	if(tile == 0) {
		return 0;
	}

	int tex_width = 256;
	int tex_height = 256;

	int row = tile / 8;
	int column = tile % 8;

	float tex_left = (column * 32.0f) / tex_width;
	float tex_right = tex_left + (1.0f / 8.0f);
	float tex_top =  (row * 32.0f) / tex_height;
	float tex_bottom = tex_top + (1.0f / 8.0f);

	glTexCoord2f(tex_left,tex_top);
	glVertex2f(x, y);
	glTexCoord2f(tex_right,tex_top);
	glVertex2f(x+32, y);
	glTexCoord2f(tex_right,tex_bottom);
	glVertex2f(x+32, y+32);
	glTexCoord2f(tex_left,tex_bottom);
	glVertex2f(x, y+32);
	
	return 0;
}

int draw_map(Map * map)
{
	glBindTexture(GL_TEXTURE_2D, m_tex_tiles);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
	for(int y = 0; y < 13; y++) {
		for(int x = 0; x < 20; x++) {
			draw_tile(map->tiles[x+y*20], (map->x*20*32)+x*32, (map->y*13*32)+y*32);
			draw_tile(map->shadow[x+y*20], (map->x*20*32)+x*32, (map->y*13*32)+y*32);
		}
	}
	glEnd();

	if(m_developer) {
		glBindTexture(GL_TEXTURE_2D, 0);
		glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
		glBegin(GL_LINES);
		for(int y = 0; y < 13; y++) {
			for(int x = 0; x < 20; x++) {
				draw_collision_tile(map->collision[x+y*20], (map->x*20*32)+x*32, (map->y*13*32)+y*32);
			}
		}
		glEnd();
	}
	
	return 0;
}

int draw_current_tile()
{
	glBindTexture(GL_TEXTURE_2D, m_tex_tiles);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
	draw_tile(m_current_tile, 16, 14*32 - 16);
	glEnd();


	glBindTexture(GL_TEXTURE_2D, 0);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
	glVertex2f(56, 14*32-16);
	glVertex2f(56+32, 14*32-16);
	glVertex2f(56+32, 14*32-16+32);
	glVertex2f(56, 14*32-16+32);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, m_tex_tiles);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
	draw_tile(m_current_tile+32, 56, 14*32 - 16);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, 0);
	glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
	glBegin(GL_LINES);
	draw_collision_tile(m_current_tile, 56+32+8, 14*32 -16);
	glEnd();
	return 0;
}

int load_objects();
int load_default_objects();
int deserialize_objects();

float m_target_rotation = 0.0f;
float m_menu_rotation = 0.0f;
int m_active_menu_item = 0;
bool m_game_started_once = false;
int tick_main()
{
	static bool right_down = false;
	static bool left_down = false;

	if(fabsf(m_menu_rotation - m_target_rotation) < 0.00001f) {
		if(m_ctrls.left && !left_down) {
			m_target_rotation = m_menu_rotation + M_PI*2 / 4.0f;
			m_active_menu_item = (m_active_menu_item + 4 - 1) % 4;
			left_down = true;
			play_sound(m_snd_menu_blip);
		} else if(m_ctrls.right && !right_down) {
			m_target_rotation = m_menu_rotation - M_PI*2 / 4.0f;
			m_active_menu_item = (m_active_menu_item + 1) % 4;
			right_down = true;
			play_sound(m_snd_menu_blip);
		}
	} else {
		if(m_target_rotation < m_menu_rotation) {
			m_menu_rotation -= fminf(0.1f, fabsf(m_target_rotation - m_menu_rotation));
		} else {
			m_menu_rotation += fminf(0.1f, fabsf(m_target_rotation - m_menu_rotation));
		}
	}

	if(!m_ctrls.right) {
		right_down = false;
	}

	if(!m_ctrls.left) {
		left_down = false;
	}

	if(m_ctrls.enter) {
		if(m_active_menu_item == 0) {
			if(!m_game_started_once || m_player.life == 0.0f) {
				if(load_objects() < 0) {
					fprintf(stdout, "Failed to load objects\n");
					return -1;
				} else {
					fprintf(stdout, "Loaded objects\n");
					deserialize_objects();
				}

				int mapx = m_player.x;
				int mapy = m_player.y;
				map_from_coords(&mapx, &mapy);

				if(load_map(mapx, mapy, &m_current_map) < 0) {
					return -1;
				} else {
					fprintf(stdout, "Loaded map\n");
				}
				m_game_started_once = true;
			}
			m_gamestate = 1;
		} else if(m_active_menu_item == 1) {
			m_gamestate = 2;
		} else if(m_active_menu_item == 2) {
			m_running = false;
		} else if(m_active_menu_item == 3) {
			reset_game();
			load_default_objects();
			deserialize_objects();
			int mapx = m_player.x;
			int mapy = m_player.y;
			map_from_coords(&mapx, &mapy);
			if(load_map(mapx, mapy, &m_current_map) < 0) {
				return -1;
			} else {
				fprintf(stdout, "Loaded map\n");
			}
			m_game_started_once = true;
			m_gamestate = 1;
		}
		m_menu_rotation = 0.0f;
		m_target_rotation = 0.0f;
		m_active_menu_item = 0;
	}
	if(m_ctrls.escape) {
		m_running = false;
	}
	
	return 0;
}

int draw_main()
{
	glClear(GL_COLOR_BUFFER_BIT);
	draw_textured_rect(m_tex_main, 0, m_screen->w, 0, m_screen->h);

	float centerx = 320;
	float centery = 328;

	{
		float x = 320 - centerx;
		float y = 250 - centery;
		float newx = cosf(m_menu_rotation) * x - sinf(m_menu_rotation) * y;
		float newy = sinf(m_menu_rotation) * x + cosf(m_menu_rotation) * y;
		newx += centerx;
		newy += centery;

		float left = newx - 16;
		float right = left + 32;
		float top = newy - 16;
		float bottom = top + 32;
		draw_textured_rect(m_tex_book, left, right, top, bottom);
		draw_text(left-23, top-12, "start game", 0.0f, 0.0f, 0.0f, 1.0f);
	}

	{
		float x = 320 - centerx;
		float y = 250 - centery;
		float newx = cosf(m_menu_rotation + M_PI*2.0f / 4.0f) * x - sinf(m_menu_rotation + M_PI*2.0f / 4.0f) * y;
		float newy = sinf(m_menu_rotation + M_PI*2.0f / 4.0f) * x + cosf(m_menu_rotation + M_PI*2.0f / 4.0f) * y;
		newx += centerx;
		newy += centery;

		float left = newx - 16;
		float right = left + 32;
		float top = newy - 16;
		float bottom = top + 32;
		draw_textured_rect(m_tex_book, left, right, top, bottom);
		draw_text(left-32, top-12, "instructions", 0.0f, 0.0f, 0.0f, 1.0f);
	}

	{
		float x = 320 - centerx;
		float y = 250 - centery;
		float newx = cosf(m_menu_rotation + M_PI) * x - sinf(m_menu_rotation + M_PI) * y;
		float newy = sinf(m_menu_rotation + M_PI) * x + cosf(m_menu_rotation + M_PI) * y;
		newx += centerx;
		newy += centery;

		float left = newx - 16;
		float right = left + 32;
		float top = newy - 16;
		float bottom = top + 32;
		draw_textured_rect(m_tex_book, left, right, top, bottom);
		draw_text(left-2, top-12, "quit", 0.0f, 0.0f, 0.0f, 1.0f);
	}

	{
		float x = 320 - centerx;
		float y = 250 - centery;
		float newx = cosf(m_menu_rotation + M_PI*6.0f / 4.0f) * x - sinf(m_menu_rotation + M_PI*6.0f / 4.0f) * y;
		float newy = sinf(m_menu_rotation + M_PI*6.0f / 4.0f) * x + cosf(m_menu_rotation + M_PI*6.0f / 4.0f) * y;
		newx += centerx;
		newy += centery;

		float left = newx - 16;
		float right = left + 32;
		float top = newy - 16;
		float bottom = top + 32;
		draw_textured_rect(m_tex_book, left, right, top, bottom);
		draw_text(left-17, top-12, "new game", 0.0f, 0.0f, 0.0f, 1.0f);
	}

	
	SDL_GL_SwapBuffers();
	return 0;
}

int tick_instructions()
{
	if(m_ctrls.escape) {
		m_gamestate = 0;
		m_ctrls.escape = false;
	}
	return 0;
}

int draw_instructions()
{
	glClear(GL_COLOR_BUFFER_BIT);
	draw_textured_rect(m_tex_instructions, 0, m_screen->w, 0, m_screen->h);
	SDL_GL_SwapBuffers();
	return 0;
}

int draw_ingame()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glPushMatrix();
	glTranslatef(-m_current_map.x * 20 * 32.0f, -m_current_map.y * 13 * 32.0f, 0.0f);

	// Draw map and transitions
	if(m_transitioning) {
		glEnable(GL_SCISSOR_TEST);
		glPushMatrix();
		glScissor(0, 480-13*32, 20*32, 13*32);
		glTranslatef(roundf(-m_transition_dir_x * m_transition_timer * 20*32),
					roundf(-m_transition_dir_y * m_transition_timer * 13*32),
					0.0f);
		draw_map(&m_current_map);
		draw_map(&m_next_map);

		draw_landed_oils();
		draw_collectibles();
		for(unsigned int i = 0; i < m_enemies.size(); i++) {
			draw_enemy(&m_enemies[i]);
		}
		draw_boss1();
		draw_boss2();
		draw_boss3();
		draw_boss4();
		draw_player();
		draw_sparks();
		draw_numbers();
		glPopMatrix();
		glDisable(GL_SCISSOR_TEST);
	} else {
		draw_map(&m_current_map);
		draw_landed_oils();
		draw_collectibles();
		for(unsigned int i = 0; i < m_enemies.size(); i++) {
			if(on_same_screen(m_enemies[i].x, m_enemies[i].y, m_player.x, m_player.y)) {
				draw_enemy(&m_enemies[i]);
			}
		}
		if(on_same_screen(m_boss1.x, m_boss1.y, m_player.x, m_player.y)) {
			draw_boss1();
		}
		if(on_same_screen(m_boss2.x, m_boss2.y, m_player.x, m_player.y)) {
			draw_boss2();
		}

		if(on_same_screen(m_boss3.x, m_boss3.y, m_player.x, m_player.y)) {
			draw_boss3();
		}
		if(on_same_screen(m_boss4.x, m_boss4.y, m_player.x, m_player.y)) {
			draw_boss4();
		}
		draw_player();
		draw_sparks();
		draw_numbers();
	}

	
	glPopMatrix();


	if(m_items[0].have_item && m_items[1].have_item && m_items[2].have_item && m_items[3].have_item && m_items[4].have_item) {
		draw_win_screen();
	}
	
	draw_overlay();
	draw_life();
	draw_inventory();

	if(m_developer) {
		draw_current_tile();
		draw_cursor();
	}

	SDL_GL_SwapBuffers();
	return 0;
}

void save_map()
{
	if(m_game_started_once) {
		char filename_buffer[512];
		sprintf(filename_buffer, "maps/room%d_%d.bin", m_current_map.x, m_current_map.y);
		
		FILE * file = fopen(filename_buffer, "wb");
		if(file == NULL) {
			fprintf(stderr, "Failed to save map.\n");
			return;
		}

		fwrite(&m_current_map, 1, sizeof(m_current_map), file);

		fclose(file);
	}
}

void place_blockade(Map * map, int x, int y)
{
	if(x < 0 || x >= 20 || y < 0 || y >= 13) {
		return;
	}
	map->tiles[x+y*20] = BLOCKADE_TILE;
	map->collision[x+y*20] = 1;
}

bool remove_blockade(Map * map, int x, int y)
{
	if(x < 0 || x >= 20 || y < 0 || y >= 13) {
		return false;
	}
	if(map->tiles[x+y*20] == BLOCKADE_TILE) {
		map->tiles[x+y*20] = FLOOR_TILE;
		map->collision[x+y*20] = 0;
		return true;
	} else {
		return false;
	}
}

bool enemies_in_map(Map * map)
{
	int enemy_count = 0;
	for(unsigned int i = 0; i < m_enemies.size(); i++) {
		if(on_map(map->x, map->y, m_enemies[i].x, m_enemies[i].y)) {
			enemy_count++;
		}
	}
	return enemy_count > 0;
}

int handle_blockades(Map * map)
{
	bool retval = false;
	if(map->x == 0 && map->y == 0) {
		if(!enemies_in_map(map)) {
			retval = remove_blockade(map, 10, 0) || retval;
			retval = remove_blockade(map, 11, 0) || retval;
		}
	} else if(map->x == 0 && map->y == -1) {
		if(!enemies_in_map(map)) {
			retval = remove_blockade(map, 0, 5) || retval;
			retval = remove_blockade(map, 0, 6) || retval;
		}
		if(m_items[C_BOOK_OIL-C_BOOK_ARSON].have_item) {
			retval = remove_blockade(map, 19, 5) || retval;
			retval = remove_blockade(map, 19, 6) || retval;
		}
	} else if(map->x == 1 && map->y == -1) {
		if(!enemies_in_map(map)) {
			retval = remove_blockade(map, 10, 0) || retval;
			retval = remove_blockade(map, 11, 0) || retval;
		}
	}
	return retval;
}

int load_map(int x, int y, Map * map)
{
	char filename_buffer[512];
	sprintf(filename_buffer, "maps/room%d_%d.bin", x,y);
	FILE * file = fopen(filename_buffer, "rb");
	if(file == NULL) {
		fprintf(stderr, "Failed to load map: %s\n", filename_buffer);
		return -1;
	}

	fread(map, 1, sizeof(Map), file);
	map->x = x;
	map->y = y;
	fclose(file);

	if(x == 0 && y == 0) {
		place_blockade(map, 10, 0);
		place_blockade(map, 11, 0);
	} else if(x == 0 && y == -1) {
		place_blockade(map, 0, 5);
		place_blockade(map, 0, 6);
		place_blockade(map, 19, 5);
		place_blockade(map, 19, 6);
	} else if(x == 1 && y == -1) {
		place_blockade(map, 10, 0);
		place_blockade(map, 11, 0);
	}

	handle_blockades(map);

	return 0;
}

void add_basic_enemy(int mapx, int mapy, int x, int y)
{
	ObjectFormat object;
	object.type = OT_ENEMY;
	object.x = (mapx*20*32.0f) + x;
	object.y = (mapy*13*32.0f) + y;
	object.alive = true;
	object.life = 1.0f;
	m_objects.push_back(object);
}

int load_default_objects()
{
	// Player
	{
		ObjectFormat object;
		object.type = OT_PLAYER;
		object.x = 320.0f;
		object.y = 320.0f;
		object.life = 1.0f;
		object.alive = true;
		m_objects.push_back(object);
	}

	// Inventory
	{
		ObjectFormat object;
		object.type = OT_INVENTORY;
		object.data[0] = 1;
		object.data[1] = 0;
		object.data[2] = 0;
		object.data[3] = 0;
		object.data[4] = 0;
		m_objects.push_back(object);
	}

	// Boss1
	{
		ObjectFormat object;
		object.type = OT_FIRST_BOSS;
		object.x = -1 * 20*32 + 64;
		object.y = -1 * 13*32 + 4*32+16;
		object.life = 1.0f;
		object.alive = true;
		object.data[0] = 0;
		m_objects.push_back(object);
	}
	
	// Boss4
	{
		ObjectFormat object;
		object.type = OT_FOURTH_BOSS;
		object.x = -2 * 20*32 + 64;
		object.y = -5 * 13*32 + 4*32+16;
		object.life = 1.0f;
		object.alive = true;
		object.data[0] = 0;
		m_objects.push_back(object);
	}

	// Boss2
	{
		ObjectFormat object;
		object.type = OT_SECOND_BOSS;
		object.x = 1 * 20*32 + 320-64;
		object.y = -2 * 13*32 + 240-128-64;
		object.life = 1.0f;
		object.alive = true;
		object.data[0] = 0;
		m_objects.push_back(object);
	}

	// Boss3 (the fence)
	{
		ObjectFormat object;
		object.type = OT_FENCE;
		object.x = 1 * 20*32 + 8*32-16;
		object.y = -2 * 13*32;
		object.life = 1.0f;
		object.alive = true;
		m_objects.push_back(object);
	}
	
	// Enemies
	{
		// Room 0,0
		for(int i = 0; i < 8; i++) {
			add_basic_enemy(0, 0, 30, 40 + i * 40);
			add_basic_enemy(0, 0, 60, 50 + i * 40);
		}

		// Room 0,-1
		for(int i = 0; i < 8; i++) {
			add_basic_enemy(0, -1, 30, 40 + i * 40);
		}
		for(int i = 0; i < 14; i++) {
			add_basic_enemy(0, -1, 30 + i * 40, 40);
		}
		for(int i = 0; i < 8; i++) {
			add_basic_enemy(0, -1, 600, 40 + i * 40);
		}

		// Room 1,-1
		for(int i = 0; i < 9; i++) {
			add_basic_enemy(1, -1, 625, 40 + i * 40);
			add_basic_enemy(1, -1, 600, 40 + i * 40);
			add_basic_enemy(1, -1, 575, 40 + i * 40);
			add_basic_enemy(1, -1, 550, 40 + i * 40);
			add_basic_enemy(1, -1, 525, 40 + i * 40);
			add_basic_enemy(1, -1, 500, 40 + i * 40);
			add_basic_enemy(1, -1, 475, 40 + i * 40);
			add_basic_enemy(1, -1, 450, 40 + i * 40);
		}

		// Room 1,-3 (above boss 2)
		for(int i = 0; i < 15; i++) {
			add_basic_enemy(1, -3, 40 + i * 40, 50);
			add_basic_enemy(1, -3, 40 + i * 40, 75);
			add_basic_enemy(1, -3, 40 + i * 40, 100);
			add_basic_enemy(1, -3, 40 + i * 40, 125);
			add_basic_enemy(1, -3, 40 + i * 40, 150);
			add_basic_enemy(1, -3, 40 + i * 40, 175);
			add_basic_enemy(1, -3, 40 + i * 40, 200);
		}

		// Room 0,-3 
		for(int i = 0; i < 9; i++) {
			for(int j = 1; j < 13; j++) {
				add_basic_enemy(0, -3, j*25, 40 + i * 40);
			}
		}
	}

	return 0;
}

int deserialize_objects()
{
	for(unsigned int i = 0; i < m_objects.size(); i++) {
		if(m_objects[i].type == OT_PLAYER) {
			m_player.anim = 0;
			m_player.invul_time = 0.0f;
			m_player.anim_time = 0.0f;
			m_player.speed = 3.0f;
			m_player.w = 32.0f;
			m_player.h = 32.0f;
			m_player.dx = 0;
			m_player.dy = -1;
			m_player.active_slot = 0;
			m_player.nullify_active = false;
			m_player.light_active = false;
			m_player.x = m_objects[i].x;
			m_player.y = m_objects[i].y;
			m_player.life = m_objects[i].life;
			m_player.object_idx = i;
		} else if(m_objects[i].type == OT_INVENTORY) {
			m_items[0].have_item = m_objects[i].data[0];
			m_items[1].have_item = m_objects[i].data[1];
			m_items[2].have_item = m_objects[i].data[2];
			m_items[3].have_item = m_objects[i].data[3];
			m_items[4].have_item = m_objects[i].data[4];
			m_items_object_idx = i;
		} else if(m_objects[i].type == OT_FIRST_BOSS) {
			m_boss1.object_idx = i;
			m_boss1.x = m_objects[i].x;
			m_boss1.y = m_objects[i].y;
			m_boss1.w = 128;
			m_boss1.h = 128;
			m_boss1.life = m_objects[i].life;
			m_boss1.report_time = 0.0f;
			m_boss1.reported_life = m_boss1.life;
			m_boss1.state = m_objects[i].data[0];
			m_boss1.state_ttl = 0.0f;
			m_boss1.invul_time = 0.0f;
		} else if(m_objects[i].type == OT_FOURTH_BOSS) {
			m_boss4.object_idx = i;
			m_boss4.x = m_objects[i].x;
			m_boss4.y = m_objects[i].y;
			m_boss4.w = 128;
			m_boss4.h = 128;
			m_boss4.is_lasing = false;
			m_boss4.life = m_objects[i].life;
			m_boss4.report_time = 0.0f;
			m_boss4.reported_life = m_boss4.life;
			m_boss4.state = m_objects[i].data[0];
			m_boss4.state_ttl = 0.0f;
			m_boss4.invul_time = 0.0f;
		} else if(m_objects[i].type == OT_SECOND_BOSS) {
			m_boss2.object_idx = i;
			m_boss2.x = m_objects[i].x;
			m_boss2.y = m_objects[i].y;
			m_boss2.vx = 1.0f;
			m_boss2.vy = 1.0f;
			m_boss2.w = 128;
			m_boss2.h = 128;
			m_boss2.life = m_objects[i].life;
			m_boss2.report_time = 0.0f;
			m_boss2.reported_life = m_boss2.life;
			m_boss2.state = m_objects[i].data[0];
			m_boss2.state_ttl = 0.0f;
			m_boss2.invul_time = 0.0f;
		} else if(m_objects[i].type == OT_FENCE) {
			m_boss3.object_idx = i;
			m_boss3.x = m_objects[i].x;
			m_boss3.y = m_objects[i].y;
			m_boss3.w = 128;
			m_boss3.h = 32;
			m_boss3.life = m_objects[i].life;
			m_boss3.report_time = 0.0f;
			m_boss3.reported_life = m_boss3.life;
			m_boss3.state = m_objects[i].data[0];
			m_boss3.state_ttl = 0.0f;
			m_boss3.invul_time = 0.0f;
		} else if(m_objects[i].type == OT_ENEMY) {
			if(!m_objects[i].alive) {
				continue;
			}
			Enemy enemy;
			memset(&enemy, 0x0, sizeof(Enemy));
			enemy.x = m_objects[i].x;
			enemy.y = m_objects[i].y;
			enemy.w = 32.0f;
			enemy.h = 32.0f;
			enemy.life = m_objects[i].life;
			enemy.object_idx = i;
			m_enemies.push_back(enemy);
		} else if(m_objects[1].type == OT_BOOK) {
			
		}
	}
	return 0;
}

int save_objects()
{
	FILE * file = fopen("objects.bin", "wb");
	if(file == NULL) {
		fprintf(stderr, "Failed to write to file objects.bin (savegame)\n");
		return -1;
	}

	// Boss1
	m_objects[m_boss1.object_idx].x = m_boss1.x;
	m_objects[m_boss1.object_idx].y = m_boss1.y;
	m_objects[m_boss1.object_idx].life = m_boss1.life;
	m_objects[m_boss1.object_idx].data[0] = m_boss1.state;
	
	// Boss4
	m_objects[m_boss4.object_idx].x = m_boss4.x;
	m_objects[m_boss4.object_idx].y = m_boss4.y;
	m_objects[m_boss4.object_idx].life = m_boss4.life;
	m_objects[m_boss4.object_idx].data[0] = m_boss4.state;
	
	// Boss2
	m_objects[m_boss2.object_idx].x = m_boss2.x;
	m_objects[m_boss2.object_idx].y = m_boss2.y;
	m_objects[m_boss2.object_idx].life = m_boss2.life;
	m_objects[m_boss2.object_idx].data[0] = m_boss2.state;
	
	// Inventory
	m_objects[m_items_object_idx].data[0] = m_items[0].have_item;
	m_objects[m_items_object_idx].data[1] = m_items[1].have_item;
	m_objects[m_items_object_idx].data[2] = m_items[2].have_item;
	m_objects[m_items_object_idx].data[3] = m_items[3].have_item;
	m_objects[m_items_object_idx].data[4] = m_items[4].have_item;

	// Player
	m_objects[m_player.object_idx].x = m_player.x;
	m_objects[m_player.object_idx].y = m_player.y;
	m_objects[m_player.object_idx].life = m_player.life;

	for(unsigned int i = 0; i < m_enemies.size(); i++) {
		int idx = m_enemies[i].object_idx;
		m_objects[idx].x = m_enemies[i].x;
		m_objects[idx].y = m_enemies[i].y;
		m_objects[idx].alive = !m_enemies[i].remove;
		m_objects[idx].life = m_enemies[i].life;
	}
	
	fwrite(&m_objects[0], 1, m_objects.size() * sizeof(ObjectFormat), file);
	fclose(file);

	set_text("game saved");
	return 0;
}


int load_objects()
{
	FILE * file = fopen("objects.bin", "rb");
	if(file == NULL) {
		fprintf(stdout, "Loading default objects (no save game found)\n");
		return load_default_objects();
	} else {
		fprintf(stdout, "Loading objects from savegame objects.bin\n");
	}
	fseek(file, 0, SEEK_END);
	size_t length = ftell(file);
	fseek(file, 0, SEEK_SET);

	m_objects.resize(length / sizeof(ObjectFormat));
	fread(&m_objects[0], 1, length, file);
	fclose(file);

	return 0;
}


int m_loop_channel = -1;
int handle_keydown(int key)
{
	if(key == SDLK_ESCAPE) {
		m_ctrls.escape = true;
	} else if(key == SDLK_RETURN) {
		m_ctrls.enter = true;
	} else if(key == SDLK_F3) {
		m_developer = !m_developer;
	} else if(key == SDLK_F5) {
		initialize_textures();
	} else if(key == SDLK_F6) {
		save_map();
		save_objects();
	} else if(key == SDLK_UP) {
		m_ctrls.up = true;
	} else if(key == SDLK_DOWN) {
		m_ctrls.down = true;
	} else if(key == SDLK_RIGHT) {
		m_ctrls.right = true;
	} else if(key == SDLK_LEFT) {
		m_ctrls.left = true;
	} else if(key == SDLK_1) {
		m_player.active_slot = 0;
	} else if(key == SDLK_2) {
		m_player.active_slot = 1;
	} else if(key == SDLK_3) {
		m_player.active_slot = 2;
	} else if(key == SDLK_4) {
		m_player.active_slot = 3;
	} else if(key == SDLK_5) {
		m_player.active_slot = 4;
	} else if(key == SDLK_z) {
		m_ctrls.z = true;
		if(m_player.active_slot == 0 && m_items[0].have_item) {
			if(m_loop_channel == -1) {
				m_loop_channel = loop_sound(m_snd_flames);
			}
		}
	}
	return 0;
}

int handle_keyup(int key)
{
	if(key == SDLK_UP) {
		m_ctrls.up = false;
	} else if(key == SDLK_ESCAPE) {
		m_ctrls.escape = false;
	} else if(key == SDLK_RETURN) {
		m_ctrls.enter = false;
	} else if(key == SDLK_DOWN) {
		m_ctrls.down = false;
	} else if(key == SDLK_RIGHT) {
		m_ctrls.right = false;
	} else if(key == SDLK_LEFT) {
		m_ctrls.left = false;
	} else if(key == SDLK_z) {
		m_ctrls.z = false;
		if(m_loop_channel != -1) {
			Mix_HaltChannel(m_loop_channel);
			m_loop_channel = -1;
		}
	}
	return 0;
}

int handle_mousebutton_down(SDL_MouseButtonEvent * event)
{
	m_mouse_x = event->x;
	m_mouse_y = event->y;

	if(event->button == SDL_BUTTON_RIGHT) {
		m_right_mouse_down = true;
	} else if(event->button == SDL_BUTTON_MIDDLE) {
		m_middle_mouse_down = true;
	} else if(event->button == SDL_BUTTON_LEFT) {
		m_left_mouse_down = true;
	} else if(event->button == SDL_BUTTON_WHEELUP) {
		m_current_tile = max(m_current_tile+1, 0);
	} else if(event->button == SDL_BUTTON_WHEELDOWN) {
		m_current_tile = max(m_current_tile-1, 0);
	}
	return 0;
}

int handle_mousebutton_up(SDL_MouseButtonEvent * event)
{
	m_mouse_x = event->x;
	m_mouse_y = event->y;
	
	if(event->button == SDL_BUTTON_RIGHT) {
		m_right_mouse_down = false;
	} else if(event->button == SDL_BUTTON_MIDDLE) {
		m_middle_mouse_down = false;
	} else if(event->button == SDL_BUTTON_LEFT) {
		m_left_mouse_down = false;
	}
	return 0;
}

int handle_mousemotion(SDL_MouseMotionEvent * event)
{
	//uint16 x, y
	//sint16 xrel, yrel
	//uint8 state

	m_mouse_x = event->x;
	m_mouse_y = event->y;

	return 0;
}

int handle_events()
{
	SDL_Event event;
	while(SDL_PollEvent(&event) == 1) {
		switch(event.type) {
			case SDL_KEYDOWN:
				if(handle_keydown((int)event.key.keysym.sym) < 0) {
					return -1;
				}
				break;
			case SDL_KEYUP:
				if(handle_keyup((int)event.key.keysym.sym) < 0) {
					return -1;
				}
				break;
			case SDL_MOUSEMOTION:
				if(handle_mousemotion(&event.motion) < 0) {
					return -1;
				}
				break;
			case SDL_MOUSEBUTTONDOWN:
				if(handle_mousebutton_down(&event.button) < 0) {
					return -1;
				}
				break;
			case SDL_MOUSEBUTTONUP:
				if(handle_mousebutton_up(&event.button) < 0) {
					return -1;
				}
				break;
			case SDL_QUIT:
				m_running = false;
				break;
			default:
				break;
		}
	}
	return 0;
}

int main(int argc, char * argv[])
{
	initialize_memory();


	if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
		fprintf(stderr, "Failed to init sdl: %s\n", SDL_GetError());
		return EXIT_FAILURE;
	} else {
		fprintf(stdout, "Initialized SDL\n");
	}

	if(IMG_Init(IMG_INIT_PNG) == 0) {
		fprintf(stderr, "Failed to initialize SDL_Image\n");
		return EXIT_FAILURE;
	} else {
		fprintf(stdout, "Initialized SDL_Image\n");
	}
	
	if(initialize_video() < 0) {
		return EXIT_FAILURE;
	} else {
		fprintf(stdout, "Initialized video\n");
	}

	if(initialize_textures() < 0) {
		return EXIT_FAILURE;
	} else {
		fprintf(stdout, "Loaded textures\n");
	}


	// Open sound mixer
	if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024) == -1) {
		fprintf(stderr, "Mix_OpenAudio: %s\n", Mix_GetError());
		return EXIT_FAILURE;
	} else {
		m_snd_potion = Mix_LoadWAV("res/snd_potion.wav");
		m_snd_hurt_spark = Mix_LoadWAV("res/snd_hurt_spark.wav");
		m_snd_flames = Mix_LoadWAV("res/snd_flames.wav");
		m_snd_boss_die = Mix_LoadWAV("res/snd_boss_die.wav");
		m_snd_menu_blip = Mix_LoadWAV("res/snd_menu_blip.wav");
		m_snd_book = Mix_LoadWAV("res/snd_book.wav");
		fprintf(stdout, "Loaded music\n");
	}

	// Main loop


	while(m_running) {
		unsigned int start_ticks = SDL_GetTicks();
		if(handle_events() < 0) {
			fprintf(stdout, "handle_events() failed\n");
			return EXIT_FAILURE;
		}

		if(m_gamestate == 0) {
			if(tick_main() < 0)
				return EXIT_FAILURE;
			if(draw_main() < 0)
				return EXIT_FAILURE;
		} else if(m_gamestate == 1) {
			if(tick_ingame() < 0)
				return EXIT_FAILURE;
			if(draw_ingame() < 0)
				return EXIT_FAILURE;
		} else if(m_gamestate == 2) {
			if(tick_instructions() < 0)
				return EXIT_FAILURE;
			if(draw_instructions() < 0)
				return EXIT_FAILURE;
		}
		unsigned int delta = SDL_GetTicks() - start_ticks;
		if(delta < 16)
			SDL_Delay(16 - delta);
	}

	return EXIT_SUCCESS;
}
